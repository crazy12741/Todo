export const colors = {
  bg: '#0E0918',
  bgDeep: '#08050F',
  card: '#19112B',
  cardRaised: '#221736',
  text: '#F3EEFF',
  textMuted: '#9A8FB8',
  accent: '#8B6BFF',
  accentDeep: '#C0ABFF',
  accentSoft: '#2A1D47',
  success: '#34D399',
  successSoft: '#123128',
  danger: '#FF6B81',
  dangerSoft: '#3A1826',
  border: '#2B2142',
  warning: '#F5A623',
};

export const priorityMeta = {
  low: { label: 'Low', color: '#5AB0FF', soft: '#152A40' },
  medium: { label: 'Medium', color: '#F5A623', soft: '#3A2A12' },
  high: { label: 'High', color: '#FF6B81', soft: '#3A1826' },
} as const;

export const radius = {
  sm: 12,
  md: 18,
  lg: 24,
  xl: 32,
};

export const shadow = {
  card: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 18,
    elevation: 3,
  },
  float: {
    shadowColor: '#6C4EF6',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.45,
    shadowRadius: 18,
    elevation: 10,
  },
};
