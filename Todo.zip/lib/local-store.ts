import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Priority, Task } from './types';

const TASKS_KEY = 'taskly.tasks.v2';
const QUEUE_KEY = 'taskly.sync-queue.v1';

export type PendingOp =
  | { kind: 'create'; task: Task }
  | { kind: 'update'; id: string; changes: { completed?: boolean; priority?: Priority } }
  | { kind: 'delete'; id: string };

export function generateTaskId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export async function loadTasks(): Promise<Task[]> {
  try {
    const raw = await AsyncStorage.getItem(TASKS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Task[]) : [];
  } catch {
    return [];
  }
}

export async function saveTasks(tasks: Task[]): Promise<void> {
  try {
    await AsyncStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  } catch {
    // storage is best-effort; the in-memory state still works
  }
}

export async function loadQueue(): Promise<PendingOp[]> {
  try {
    const raw = await AsyncStorage.getItem(QUEUE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as PendingOp[]) : [];
  } catch {
    return [];
  }
}

export async function saveQueue(ops: PendingOp[]): Promise<void> {
  try {
    await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(ops));
  } catch {
    // ignore
  }
}
