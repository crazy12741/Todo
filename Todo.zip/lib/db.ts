import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';
import * as authSchema from './auth-schema';

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error('DATABASE_URL is not set. Add it to your environment before starting the app.');
}

const globalForDb = globalThis as unknown as { __tasklyPool?: Pool };

const requiresSsl =
  /sslmode=(require|verify-ca|verify-full)/.test(connectionString) ||
  process.env.NODE_ENV === 'production';

const pool =
  globalForDb.__tasklyPool ??
  new Pool({
    connectionString,
    max: Number(process.env.PG_POOL_MAX ?? 5),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
    ssl: requiresSsl ? { rejectUnauthorized: false } : undefined,
  });

pool.on('error', (err) => {
  console.error('[db] idle client error', err.message);
});

globalForDb.__tasklyPool = pool;

export const db = drizzle(pool, { schema: { ...schema, ...authSchema } });
export { schema, authSchema, pool };
