type EmojiRule = {
  emoji: string;
  category: string;
  keywords: string[];
};

const RULES: EmojiRule[] = [
  { emoji: '💪', category: 'Health', keywords: ['gym', 'workout', 'exercise', 'lift', 'push ups', 'pushups', 'abs', 'fitness', 'training'] },
  { emoji: '🏃', category: 'Health', keywords: ['run', 'jog', 'sprint', 'marathon', 'treadmill'] },
  { emoji: '🧘', category: 'Health', keywords: ['yoga', 'meditate', 'meditation', 'mindfulness', 'stretch', 'breathe'] },
  { emoji: '🚶', category: 'Health', keywords: ['walk', 'steps', 'hike', 'hiking'] },
  { emoji: '🏊', category: 'Health', keywords: ['swim', 'swimming', 'pool'] },
  { emoji: '🩺', category: 'Health', keywords: ['doctor', 'dentist', 'clinic', 'hospital', 'checkup', 'check up', 'appointment', 'therapy', 'physio'] },
  { emoji: '💊', category: 'Health', keywords: ['medicine', 'pill', 'vitamin', 'supplement', 'prescription'] },
  { emoji: '💧', category: 'Health', keywords: ['water', 'hydrate', 'drink water'] },
  { emoji: '😴', category: 'Health', keywords: ['sleep', 'nap', 'bed', 'rest'] },
  { emoji: '💇', category: 'Personal', keywords: ['haircut', 'barber', 'salon', 'hair'] },
  { emoji: '🚿', category: 'Personal', keywords: ['shower', 'bath', 'skincare', 'brush teeth'] },
  { emoji: '☕', category: 'Food', keywords: ['coffee', 'espresso', 'latte', 'cafe'] },
  { emoji: '🍵', category: 'Food', keywords: ['tea', 'matcha'] },
  { emoji: '🥞', category: 'Food', keywords: ['breakfast', 'brunch', 'pancake'] },
  { emoji: '🍽️', category: 'Food', keywords: ['lunch', 'dinner', 'meal', 'cook', 'recipe', 'bake', 'eat'] },
  { emoji: '🍕', category: 'Food', keywords: ['pizza', 'burger', 'takeout', 'take out', 'order food'] },
  { emoji: '🛒', category: 'Errands', keywords: ['grocery', 'groceries', 'shopping', 'shop', 'buy', 'market', 'store'] },
  { emoji: '🧺', category: 'Home', keywords: ['laundry', 'fold clothes', 'iron'] },
  { emoji: '🧹', category: 'Home', keywords: ['clean', 'dishes', 'vacuum', 'tidy', 'mop', 'trash', 'organize', 'declutter'] },
  { emoji: '🌱', category: 'Home', keywords: ['plant', 'garden', 'water plants', 'repot'] },
  { emoji: '🔧', category: 'Home', keywords: ['fix', 'repair', 'assemble', 'install', 'maintenance'] },
  { emoji: '🖌️', category: 'Home', keywords: ['paint', 'renovate', 'decorate'] },
  { emoji: '🏠', category: 'Home', keywords: ['rent', 'mortgage', 'landlord', 'home', 'house', 'move'] },
  { emoji: '💳', category: 'Finance', keywords: ['bill', 'invoice', 'pay', 'tax', 'subscription', 'insurance', 'fee'] },
  { emoji: '💰', category: 'Finance', keywords: ['budget', 'finance', 'money', 'save', 'savings', 'invest', 'salary', 'expense'] },
  { emoji: '🏦', category: 'Finance', keywords: ['bank', 'transfer', 'loan'] },
  { emoji: '👥', category: 'Work', keywords: ['meeting', 'standup', 'stand up', 'sync', '1:1', 'one on one', 'team', 'interview', 'catch up'] },
  { emoji: '📊', category: 'Work', keywords: ['presentation', 'deck', 'report', 'slides', 'pitch', 'analytics'] },
  { emoji: '💼', category: 'Work', keywords: ['work', 'office', 'project', 'client', 'proposal', 'deadline', 'resume', 'cv', 'apply', 'job'] },
  { emoji: '✉️', category: 'Work', keywords: ['email', 'mail', 'inbox', 'reply', 'send'] },
  { emoji: '📞', category: 'Work', keywords: ['call', 'phone', 'ring', 'dial'] },
  { emoji: '💻', category: 'Tech', keywords: ['code', 'coding', 'program', 'bug', 'debug', 'refactor', 'api', 'feature', 'pull request', 'commit'] },
  { emoji: '🎨', category: 'Tech', keywords: ['design', 'figma', 'ui', 'ux', 'mockup', 'wireframe'] },
  { emoji: '🚀', category: 'Tech', keywords: ['deploy', 'release', 'launch', 'ship', 'publish', 'migrate'] },
  { emoji: '🔍', category: 'Tech', keywords: ['review', 'test', 'qa', 'audit', 'research'] },
  { emoji: '📚', category: 'Learning', keywords: ['study', 'learn', 'course', 'class', 'lecture', 'revision', 'flashcards', 'duolingo', 'language'] },
  { emoji: '📖', category: 'Learning', keywords: ['read', 'book', 'chapter', 'novel', 'article'] },
  { emoji: '📝', category: 'Learning', keywords: ['exam', 'test', 'homework', 'assignment', 'essay', 'write', 'notes', 'journal'] },
  { emoji: '🎵', category: 'Leisure', keywords: ['music', 'song', 'guitar', 'piano', 'practice', 'sing', 'playlist'] },
  { emoji: '🎬', category: 'Leisure', keywords: ['movie', 'film', 'netflix', 'series', 'episode', 'watch'] },
  { emoji: '🎮', category: 'Leisure', keywords: ['game', 'gaming', 'playstation', 'xbox', 'steam'] },
  { emoji: '📸', category: 'Leisure', keywords: ['photo', 'camera', 'picture', 'shoot', 'edit photos'] },
  { emoji: '✈️', category: 'Travel', keywords: ['travel', 'flight', 'plane', 'trip', 'vacation', 'holiday', 'airport', 'visa'] },
  { emoji: '🏨', category: 'Travel', keywords: ['hotel', 'booking', 'book a room', 'airbnb'] },
  { emoji: '🧳', category: 'Travel', keywords: ['pack', 'packing', 'luggage', 'suitcase'] },
  { emoji: '🚗', category: 'Errands', keywords: ['car', 'drive', 'oil change', 'gas', 'fuel', 'car wash', 'dmv'] },
  { emoji: '🚲', category: 'Errands', keywords: ['bike', 'cycle', 'bicycle'] },
  { emoji: '📦', category: 'Errands', keywords: ['package', 'delivery', 'parcel', 'return', 'pickup', 'pick up', 'drop off'] },
  { emoji: '🎉', category: 'Social', keywords: ['party', 'birthday', 'celebrate', 'anniversary', 'event'] },
  { emoji: '🎁', category: 'Social', keywords: ['gift', 'present', 'surprise'] },
  { emoji: '💍', category: 'Social', keywords: ['wedding', 'proposal', 'engagement'] },
  { emoji: '💕', category: 'Social', keywords: ['date', 'romantic', 'partner', 'wife', 'husband', 'girlfriend', 'boyfriend'] },
  { emoji: '👨‍👩‍👧', category: 'Social', keywords: ['family', 'mom', 'dad', 'parents', 'kids', 'children', 'grandma', 'grandpa'] },
  { emoji: '🐶', category: 'Pets', keywords: ['dog', 'puppy', 'walk the dog', 'vet', 'pet'] },
  { emoji: '🐱', category: 'Pets', keywords: ['cat', 'kitten', 'litter'] },
  { emoji: '📅', category: 'Planning', keywords: ['plan', 'schedule', 'calendar', 'organize week', 'goal', 'review week', 'agenda'] },
  { emoji: '🔔', category: 'Planning', keywords: ['reminder', 'remember', 'follow up', 'don\'t forget'] },
];

const FALLBACK: { emoji: string; category: string } = { emoji: '📝', category: 'General' };

export function detectEmoji(title: string): { emoji: string; category: string } {
  const text = ` ${title.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ')} `;

  for (const rule of RULES) {
    for (const keyword of rule.keywords) {
      if (text.includes(` ${keyword} `) || text.includes(` ${keyword}s `) || text.includes(` ${keyword}ing `)) {
        return { emoji: rule.emoji, category: rule.category };
      }
    }
  }

  for (const rule of RULES) {
    for (const keyword of rule.keywords) {
      if (keyword.length > 3 && text.includes(keyword)) {
        return { emoji: rule.emoji, category: rule.category };
      }
    }
  }

  return FALLBACK;
}

export const QUICK_IDEAS: { label: string; title: string; priority: 'low' | 'medium' | 'high' }[] = [
  { label: 'Morning run', title: 'Morning run 5km', priority: 'medium' },
  { label: 'Team standup', title: 'Team standup at 10am', priority: 'high' },
  { label: 'Buy groceries', title: 'Buy groceries for the week', priority: 'medium' },
  { label: 'Read a book', title: 'Read 20 pages of a book', priority: 'low' },
  { label: 'Pay bills', title: 'Pay electricity bill', priority: 'high' },
  { label: 'Call mom', title: 'Call mom', priority: 'low' },
];
