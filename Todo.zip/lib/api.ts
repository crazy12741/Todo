import { db } from '@/lib/db';
import { user } from '@/lib/auth-schema';

export const SHARED_USER_ID = 'shared-taskly-user';

let ensured = false;

export async function getTaskOwnerId(): Promise<string> {
  if (!ensured) {
    await db
      .insert(user)
      .values({
        id: SHARED_USER_ID,
        name: 'Taskly',
        email: 'shared@taskly.local',
        emailVerified: true,
      })
      .onConflictDoNothing();
    ensured = true;
  }
  return SHARED_USER_ID;
}

export function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

export const badRequest = (message: string) => json({ error: message }, 400);
export const serverError = () => json({ error: 'Something went wrong. Please try again.' }, 500);
