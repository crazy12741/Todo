export type Priority = 'low' | 'medium' | 'high';

export type Task = {
  id: string;
  title: string;
  emoji: string;
  category: string;
  priority: Priority;
  completed: boolean;
  createdAt: number;
  completedAt?: number;
};

export type TaskDraft = {
  title: string;
  priority: Priority;
};
