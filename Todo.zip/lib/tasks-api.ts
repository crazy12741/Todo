import type { Priority, Task } from './types';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });

  let body: unknown = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }

  if (!response.ok) {
    const message =
      body && typeof body === 'object' && 'error' in body
        ? String((body as { error: unknown }).error)
        : 'Request failed. Please try again.';
    throw new ApiError(message, response.status);
  }

  return body as T;
}

export function fetchTasks() {
  return request<{ tasks: Task[] }>('/api/tasks').then((data) => data.tasks);
}

export function createTask(input: {
  id?: string;
  title: string;
  priority: Priority;
  completed?: boolean;
}) {
  return request<{ task: Task }>('/api/tasks', {
    method: 'POST',
    body: JSON.stringify(input),
  }).then((data) => data.task);
}

export function updateTask(id: string, input: { completed?: boolean; priority?: Priority }) {
  return request<{ task: Task }>(`/api/tasks/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(input),
  }).then((data) => data.task);
}

export function removeTask(id: string) {
  return request<{ ok: true }>(`/api/tasks/${id}`, { method: 'DELETE' });
}
