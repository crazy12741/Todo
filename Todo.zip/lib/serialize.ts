import type { TaskRow } from './schema';
import type { Priority, Task } from './types';

const PRIORITIES: Priority[] = ['low', 'medium', 'high'];

export function isPriority(value: unknown): value is Priority {
  return typeof value === 'string' && (PRIORITIES as string[]).includes(value);
}

export function serializeTask(row: TaskRow): Task {
  return {
    id: row.id,
    title: row.title,
    emoji: row.emoji,
    category: row.category,
    priority: isPriority(row.priority) ? row.priority : 'medium',
    completed: row.completed,
    createdAt: row.createdAt.getTime(),
    completedAt: row.completedAt ? row.completedAt.getTime() : undefined,
  };
}
