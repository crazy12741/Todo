import { useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Sparkles, X } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { colors, priorityMeta, radius, shadow } from '@/constants/theme';
import { detectEmoji, QUICK_IDEAS } from '@/lib/emoji';
import { useTasks } from '@/store/TasksContext';
import type { Priority } from '@/lib/types';

const PRIORITIES: Priority[] = ['low', 'medium', 'high'];

export default function AddTaskScreen() {
  const { addTask } = useTasks();
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const detection = useMemo(() => detectEmoji(title), [title]);
  const canSave = title.trim().length > 0 && !saving;

  const handleSave = async () => {
    if (!canSave) return;
    setSaving(true);
    setError(null);
    try {
      await addTask({ title, priority });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      router.back();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save the task. Please try again.');
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom', 'left', 'right']}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.topBar}>
          <Pressable
            onPress={() => router.back()}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel="Close"
            style={({ pressed }) => [styles.closeBtn, pressed && styles.pressed]}
          >
            <X size={20} color={colors.text} />
          </Pressable>
          <Text style={styles.topTitle}>New task</Text>
          <View style={styles.closeBtn} />
        </View>

        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.previewWrap}>
            <View style={styles.previewGlow}>
              <Text style={styles.previewEmoji}>{detection.emoji}</Text>
            </View>
            <View style={styles.previewChip}>
              <Sparkles size={11} color={colors.accentDeep} />
              <Text style={styles.previewChipText}>
                {title.trim().length > 0 ? detection.category : 'Emoji auto-picked for you'}
              </Text>
            </View>
          </View>

          <View style={styles.inputCard}>
            <Text style={styles.inputLabel}>What needs to be done?</Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="e.g. Morning run 5km"
              placeholderTextColor="#6E6388"
              style={styles.input}
              autoFocus
              returnKeyType="done"
              onSubmitEditing={handleSave}
              maxLength={120}
              multiline
            />
            <Text style={styles.charCount}>{title.length}/120</Text>
          </View>

          {error ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <View>
            <Text style={styles.sectionTitle}>Priority</Text>
            <View style={styles.priorityRow}>
              {PRIORITIES.map((item) => {
                const meta = priorityMeta[item];
                const active = priority === item;
                return (
                  <Pressable
                    key={item}
                    onPress={() => setPriority(item)}
                    accessibilityRole="radio"
                    accessibilityState={{ selected: active }}
                    style={[
                      styles.priorityChip,
                      { backgroundColor: active ? meta.color : meta.soft },
                    ]}
                  >
                    <Text
                      style={[
                        styles.priorityChipText,
                        { color: active ? '#FFFFFF' : meta.color },
                      ]}
                    >
                      {meta.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          <View>
            <Text style={styles.sectionTitle}>Quick ideas</Text>
            <View style={styles.ideasWrap}>
              {QUICK_IDEAS.map((idea) => (
                <Pressable
                  key={idea.label}
                  onPress={() => {
                    setTitle(idea.title);
                    setPriority(idea.priority);
                  }}
                  style={({ pressed }) => [styles.ideaChip, pressed && styles.pressed]}
                >
                  <Text style={styles.ideaText}>{detectEmoji(idea.title).emoji}</Text>
                  <Text style={styles.ideaLabel}>{idea.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          <Pressable
            onPress={handleSave}
            disabled={!canSave}
            accessibilityRole="button"
            accessibilityState={{ disabled: !canSave }}
            style={({ pressed }) => [
              styles.saveWrap,
              pressed && canSave && styles.pressed,
              !canSave && styles.saveDisabled,
            ]}
          >
            <LinearGradient
              colors={canSave ? ['#7B5BFF', '#5B3DE8'] : ['#2A2140', '#241B38']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.saveBtn}
            >
              <Text style={styles.saveText}>{saving ? 'Saving…' : 'Add task'}</Text>
            </LinearGradient>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  flex: {
    flex: 1,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  closeBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  topTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
  },
  content: {
    paddingHorizontal: 22,
    paddingTop: 6,
    paddingBottom: 32,
    gap: 22,
  },
  previewWrap: {
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  previewGlow: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: colors.accentSoft,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadow.card,
  },
  previewEmoji: {
    fontSize: 46,
  },
  previewChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  previewChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.accentDeep,
  },
  inputCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: 18,
    gap: 6,
    ...shadow.card,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textMuted,
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  input: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    paddingVertical: 6,
    minHeight: 48,
    maxHeight: 130,
    textAlignVertical: 'top',
  },
  charCount: {
    alignSelf: 'flex-end',
    fontSize: 11,
    fontWeight: '500',
    color: colors.textMuted,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
  },
  priorityRow: {
    flexDirection: 'row',
    gap: 10,
  },
  priorityChip: {
    flex: 1,
    paddingVertical: 13,
    borderRadius: radius.sm,
    alignItems: 'center',
  },
  priorityChipText: {
    fontSize: 13.5,
    fontWeight: '700',
  },
  ideasWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  ideaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 13,
    paddingVertical: 9,
    borderRadius: 20,
  },
  ideaText: {
    fontSize: 14,
  },
  ideaLabel: {
    fontSize: 12.5,
    fontWeight: '600',
    color: colors.text,
  },
  saveWrap: {
    borderRadius: radius.md,
    overflow: 'hidden',
    ...shadow.float,
  },
  saveDisabled: {
    shadowOpacity: 0,
    elevation: 0,
  },
  saveBtn: {
    paddingVertical: 17,
    alignItems: 'center',
    borderRadius: radius.md,
  },
  saveText: {
    fontSize: 15.5,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: 0.2,
  },
  pressed: {
    opacity: 0.85,
  },
  errorBox: {
    backgroundColor: colors.dangerSoft,
    borderRadius: radius.sm,
    paddingVertical: 11,
    paddingHorizontal: 14,
  },
  errorText: {
    color: colors.danger,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
  },
});
