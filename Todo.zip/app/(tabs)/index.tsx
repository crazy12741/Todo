import { useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Plus, Sparkles } from 'lucide-react-native';
import { EmptyState } from '@/components/EmptyState';
import { FilterChips, type Filter } from '@/components/FilterChips';
import { ProgressRing } from '@/components/ProgressRing';
import { TaskItem } from '@/components/TaskItem';
import { colors, radius, shadow } from '@/constants/theme';
import { useTasks } from '@/store/TasksContext';
import type { Priority, Task } from '@/lib/types';

const PRIORITY_ORDER: Record<Priority, number> = { high: 0, medium: 1, low: 2 };

function greetingFor(hour: number) {
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function sortTasks(tasks: Task[]) {
  return [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    if (a.completed && b.completed) return (b.completedAt ?? 0) - (a.completedAt ?? 0);
    const byPriority = PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
    if (byPriority !== 0) return byPriority;
    return b.createdAt - a.createdAt;
  });
}

export default function TasksScreen() {
  const { tasks, loading, error, offline, pendingCount, toggleTask, deleteTask } = useTasks();
  const [filter, setFilter] = useState<Filter>('all');

  const counts = useMemo(
    () => ({
      all: tasks.length,
      active: tasks.filter((task) => !task.completed).length,
      completed: tasks.filter((task) => task.completed).length,
    }),
    [tasks]
  );

  const visibleTasks = useMemo(() => {
    const filtered =
      filter === 'active'
        ? tasks.filter((task) => !task.completed)
        : filter === 'completed'
          ? tasks.filter((task) => task.completed)
          : tasks;
    return sortTasks(filtered);
  }, [tasks, filter]);

  const doneCount = counts.completed;
  const total = counts.all;
  const progress = total === 0 ? 0 : doneCount / total;
  const percent = Math.round(progress * 100);

  const now = new Date();
  const dateLabel = now.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });

  const emptyContent = {
    all: {
      emoji: '🌤️',
      title: 'Your day is clear',
      message: 'Add your first task and we will pick the perfect emoji for it.',
    },
    active: {
      emoji: '🎉',
      title: 'All caught up',
      message: 'Every task is done. Take a breath — you earned it.',
    },
    completed: {
      emoji: '📋',
      title: 'Nothing completed yet',
      message: 'Check off a task and it will show up here.',
    },
  }[filter];

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>{greetingFor(now.getHours())}</Text>
          <Text style={styles.date}>{dateLabel}</Text>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarEmoji}>🙂</Text>
        </View>
      </View>

      <FlatList
        data={visibleTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem task={item} onToggle={toggleTask} onDelete={deleteTask} />
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={styles.headerBlock}>
            <LinearGradient
              colors={['#6C4EF6', '#8A66FF', '#B08DFF']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.progressCard}
            >
              <View style={styles.progressTextWrap}>
                <View style={styles.eyebrowRow}>
                  <Sparkles size={13} color="#E4DAFF" />
                  <Text style={styles.eyebrow}>TODAY'S PROGRESS</Text>
                </View>
                <Text style={styles.progressHeadline}>
                  {total === 0
                    ? 'Fresh start'
                    : percent === 100
                      ? 'All done! 🎉'
                      : percent >= 50
                        ? 'On a roll'
                        : 'Let’s get going'}
                </Text>
                <Text style={styles.progressSub}>
                  {doneCount} of {total} tasks completed
                </Text>
                <View style={styles.track}>
                  <View style={[styles.fill, { width: `${Math.max(percent, 2)}%` }]} />
                </View>
              </View>
              <ProgressRing
                size={78}
                strokeWidth={8}
                progress={progress}
                color="#FFFFFF"
                trackColor="rgba(255,255,255,0.28)"
              >
                <Text style={styles.ringValue}>{percent}%</Text>
              </ProgressRing>
            </LinearGradient>

            <FilterChips value={filter} counts={counts} onChange={setFilter} />

            {offline ? (
              <View style={styles.offlineRow}>
                <View style={styles.offlineDot} />
                <Text style={styles.offlineText}>
                  Offline · saved on this device
                  {pendingCount > 0 ? ` · ${pendingCount} change${pendingCount === 1 ? '' : 's'} to sync` : ''}
                </Text>
              </View>
            ) : null}

            {error ? (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : null}

            {counts.active > 0 && filter !== 'completed' ? (
              <Text style={styles.sectionLabel}>
                {counts.active} {counts.active === 1 ? 'task' : 'tasks'} to go
              </Text>
            ) : null}
          </View>
        }
        ListEmptyComponent={
          loading ? (
            <View style={styles.loadingWrap}>
              <ActivityIndicator color={colors.accent} />
            </View>
          ) : (
            <EmptyState
              emoji={emptyContent.emoji}
              title={emptyContent.title}
              message={emptyContent.message}
              tone={filter === 'active' ? 'success' : 'accent'}
            />
          )
        }
        ListFooterComponent={<View style={{ height: 110 }} />}
      />

      <Pressable
        onPress={() => router.push('/add-task')}
        accessibilityRole="button"
        accessibilityLabel="Add a new task"
        style={({ pressed }) => [styles.fab, pressed && styles.fabPressed]}
      >
        <LinearGradient
          colors={['#7B5BFF', '#5B3DE8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.fabGradient}
        >
          <Plus size={28} color="#FFFFFF" strokeWidth={2.6} />
        </LinearGradient>
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
    paddingTop: 8,
    paddingBottom: 16,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
    letterSpacing: -0.4,
  },
  date: {
    marginTop: 3,
    fontSize: 13.5,
    fontWeight: '500',
    color: colors.textMuted,
  },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    ...shadow.card,
  },
  avatarEmoji: {
    fontSize: 22,
  },
  listContent: {
    paddingHorizontal: 22,
  },
  headerBlock: {
    gap: 16,
    marginBottom: 8,
  },
  progressCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: radius.lg,
    padding: 20,
    ...shadow.float,
  },
  progressTextWrap: {
    flex: 1,
    gap: 6,
  },
  eyebrowRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  eyebrow: {
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 1.2,
    color: '#E7DEFF',
  },
  progressHeadline: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: -0.3,
  },
  progressSub: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '500',
  },
  track: {
    height: 7,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.25)',
    overflow: 'hidden',
    marginTop: 6,
  },
  fill: {
    height: '100%',
    borderRadius: 4,
    backgroundColor: '#FFFFFF',
  },
  ringValue: {
    fontSize: 17,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textMuted,
    letterSpacing: 0.2,
    marginTop: 4,
  },
  loadingWrap: {
    paddingVertical: 60,
    alignItems: 'center',
  },
  fab: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    borderRadius: 30,
    ...shadow.float,
  },
  fabPressed: {
    transform: [{ scale: 0.94 }],
  },
  fabGradient: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorBox: {
    backgroundColor: colors.dangerSoft,
    borderRadius: radius.sm,
    paddingVertical: 11,
    paddingHorizontal: 14,
  },
  errorText: {
    color: colors.danger,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
  },
  offlineRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    backgroundColor: colors.card,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: 9,
    paddingHorizontal: 12,
  },
  offlineDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.warning,
  },
  offlineText: {
    flex: 1,
    fontSize: 12,
    fontWeight: '600',
    color: colors.textMuted,
  },
});
