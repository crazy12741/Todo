import { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Trash2, TrendingUp } from 'lucide-react-native';
import { EmptyState } from '@/components/EmptyState';
import { ProgressRing } from '@/components/ProgressRing';
import { colors, priorityMeta, radius, shadow } from '@/constants/theme';
import { useTasks } from '@/store/TasksContext';
import type { Priority } from '@/lib/types';

const PRIORITIES: Priority[] = ['high', 'medium', 'low'];

export default function InsightsScreen() {
  const { tasks, clearCompleted } = useTasks();

  const stats = useMemo(() => {
    const total = tasks.length;
    const done = tasks.filter((task) => task.completed).length;
    const active = total - done;
    const rate = total === 0 ? 0 : Math.round((done / total) * 100);

    const byPriority = PRIORITIES.map((priority) => ({
      priority,
      total: tasks.filter((task) => task.priority === priority).length,
      done: tasks.filter((task) => task.priority === priority && task.completed).length,
    }));

    const categoryMap = new Map<string, { emoji: string; total: number; done: number }>();
    for (const task of tasks) {
      const entry = categoryMap.get(task.category) ?? { emoji: task.emoji, total: 0, done: 0 };
      entry.total += 1;
      if (task.completed) entry.done += 1;
      categoryMap.set(task.category, entry);
    }
    const categories = [...categoryMap.entries()]
      .map(([name, value]) => ({ name, ...value }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);

    return { total, done, active, rate, byPriority, categories };
  }, [tasks]);

  const maxPriority = Math.max(1, ...stats.byPriority.map((item) => item.total));

  if (tasks.length === 0) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
        <View style={styles.header}>
          <Text style={styles.title}>Insights</Text>
          <Text style={styles.subtitle}>A look at your momentum</Text>
        </View>
        <EmptyState
          emoji="📊"
          title="No data yet"
          message="Add a few tasks and your progress will appear here."
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Insights</Text>
          <Text style={styles.subtitle}>A look at your momentum</Text>
        </View>

        <View style={styles.heroCard}>
          <ProgressRing
            size={104}
            strokeWidth={11}
            progress={stats.rate / 100}
            color={colors.accent}
            trackColor={colors.accentSoft}
          >
            <Text style={styles.heroValue}>{stats.rate}%</Text>
            <Text style={styles.heroValueLabel}>done</Text>
          </ProgressRing>
          <View style={styles.heroText}>
            <View style={styles.heroBadge}>
              <TrendingUp size={12} color={colors.accentDeep} />
              <Text style={styles.heroBadgeText}>Completion rate</Text>
            </View>
            <Text style={styles.heroHeadline}>
              {stats.rate >= 70 ? 'Crushing it' : stats.rate >= 40 ? 'Nice momentum' : 'Keep going'}
            </Text>
            <Text style={styles.heroSub}>
              {stats.done} of {stats.total} tasks finished
            </Text>
          </View>
        </View>

        <View style={styles.statRow}>
          <StatTile emoji="🗂️" label="Total" value={stats.total} tint={colors.accentSoft} />
          <StatTile emoji="✅" label="Done" value={stats.done} tint={colors.successSoft} />
          <StatTile emoji="⏳" label="Active" value={stats.active} tint="#3A2A12" />
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>By priority</Text>
          <View style={styles.cardBody}>
            {stats.byPriority.map(({ priority, total, done }) => {
              const meta = priorityMeta[priority];
              return (
                <View key={priority} style={styles.priorityRow}>
                  <View style={[styles.priorityDot, { backgroundColor: meta.color }]} />
                  <Text style={styles.priorityLabel}>{meta.label}</Text>
                  <View style={styles.barTrack}>
                    <View
                      style={[
                        styles.barFill,
                        {
                          width: `${(total / maxPriority) * 100}%`,
                          backgroundColor: meta.color,
                        },
                      ]}
                    />
                  </View>
                  <Text style={styles.priorityCount}>
                    {done}/{total}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Top categories</Text>
          <View style={styles.cardBody}>
            {stats.categories.map((category) => (
              <View key={category.name} style={styles.categoryRow}>
                <View style={styles.categoryEmojiWrap}>
                  <Text style={styles.categoryEmoji}>{category.emoji}</Text>
                </View>
                <View style={styles.categoryInfo}>
                  <View style={styles.categoryTitleRow}>
                    <Text style={styles.categoryName}>{category.name}</Text>
                    <Text style={styles.categoryCount}>
                      {category.done}/{category.total}
                    </Text>
                  </View>
                  <View style={styles.barTrack}>
                    <View
                      style={[
                        styles.barFill,
                        {
                          width: `${(category.done / category.total) * 100}%`,
                          backgroundColor: colors.accent,
                        },
                      ]}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>
        </View>

        {stats.done > 0 ? (
          <Pressable
            onPress={() => void clearCompleted()}
            accessibilityRole="button"
            style={({ pressed }) => [styles.clearBtn, pressed && styles.clearBtnPressed]}
          >
            <Trash2 size={16} color={colors.danger} />
            <Text style={styles.clearText}>Clear {stats.done} completed</Text>
          </Pressable>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function StatTile({
  emoji,
  label,
  value,
  tint,
}: {
  emoji: string;
  label: string;
  value: number;
  tint: string;
}) {
  return (
    <View style={[styles.statTile, { backgroundColor: tint }]}>
      <Text style={styles.statEmoji}>{emoji}</Text>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  content: {
    paddingHorizontal: 22,
    paddingBottom: 40,
  },
  header: {
    paddingTop: 8,
    paddingBottom: 18,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.text,
    letterSpacing: -0.5,
  },
  subtitle: {
    marginTop: 4,
    fontSize: 13.5,
    fontWeight: '500',
    color: colors.textMuted,
  },
  heroCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 18,
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: 20,
    ...shadow.card,
  },
  heroValue: {
    fontSize: 26,
    fontWeight: '800',
    color: colors.text,
  },
  heroValueLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.textMuted,
  },
  heroText: {
    flex: 1,
    gap: 6,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    backgroundColor: colors.accentSoft,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 8,
  },
  heroBadgeText: {
    fontSize: 10.5,
    fontWeight: '700',
    color: colors.accentDeep,
  },
  heroHeadline: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.text,
  },
  heroSub: {
    fontSize: 13,
    color: colors.textMuted,
    fontWeight: '500',
  },
  statRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  statTile: {
    flex: 1,
    borderRadius: radius.md,
    paddingVertical: 16,
    alignItems: 'center',
    gap: 3,
  },
  statEmoji: {
    fontSize: 20,
  },
  statValue: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.text,
  },
  statLabel: {
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.textMuted,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: 20,
    marginTop: 16,
    ...shadow.card,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 16,
  },
  cardBody: {
    gap: 14,
  },
  priorityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  priorityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  priorityLabel: {
    width: 58,
    fontSize: 13,
    fontWeight: '600',
    color: colors.text,
  },
  barTrack: {
    flex: 1,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bg,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 4,
    minWidth: 4,
  },
  priorityCount: {
    width: 40,
    textAlign: 'right',
    fontSize: 12,
    fontWeight: '600',
    color: colors.textMuted,
  },
  categoryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  categoryEmojiWrap: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: colors.accentSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryEmoji: {
    fontSize: 18,
  },
  categoryInfo: {
    flex: 1,
    gap: 7,
  },
  categoryTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  categoryName: {
    fontSize: 13.5,
    fontWeight: '600',
    color: colors.text,
  },
  categoryCount: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textMuted,
  },
  clearBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 20,
    paddingVertical: 15,
    borderRadius: radius.md,
    backgroundColor: colors.dangerSoft,
  },
  clearBtnPressed: {
    opacity: 0.75,
  },
  clearText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.danger,
  },
});
