import { sql } from 'drizzle-orm';
import { db } from '@/lib/db';
import { json } from '@/lib/api';

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    return json({ status: 'ok', database: 'connected' });
  } catch {
    return json({ status: 'error', database: 'unreachable' }, 503);
  }
}
