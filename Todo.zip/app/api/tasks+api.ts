import { and, desc, eq } from 'drizzle-orm';
import { z } from 'zod';
import { badRequest, getTaskOwnerId, json, serverError } from '@/lib/api';
import { db } from '@/lib/db';
import { detectEmoji } from '@/lib/emoji';
import { tasks } from '@/lib/schema';
import { serializeTask } from '@/lib/serialize';

const createSchema = z.object({
  id: z.string().trim().min(1).max(64).optional(),
  title: z.string().trim().min(1, 'Task title is required').max(120),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  completed: z.boolean().optional(),
});

export async function GET() {
  try {
    const userId = await getTaskOwnerId();
    const rows = await db
      .select()
      .from(tasks)
      .where(eq(tasks.userId, userId))
      .orderBy(desc(tasks.createdAt));
    return json({ tasks: rows.map(serializeTask) });
  } catch {
    return serverError();
  }
}

export async function POST(request: Request) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return badRequest('Invalid request body.');
  }

  const parsed = createSchema.safeParse(payload);
  if (!parsed.success) {
    return badRequest(parsed.error.issues[0]?.message ?? 'Invalid task.');
  }

  const { title, priority, completed } = parsed.data;
  const { emoji, category } = detectEmoji(title);

  try {
    const userId = await getTaskOwnerId();
    const [row] = await db
      .insert(tasks)
      .values({
        id: parsed.data.id ?? crypto.randomUUID(),
        userId,
        title,
        emoji,
        category,
        priority,
        completed: completed ?? false,
        completedAt: completed ? new Date() : null,
      })
      .onConflictDoNothing({ target: tasks.id })
      .returning();

    if (row) return json({ task: serializeTask(row) }, 201);

    const [existing] = await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.id, parsed.data.id ?? ''), eq(tasks.userId, userId)))
      .limit(1);
    if (!existing) return json({ error: 'Task already exists.' }, 409);
    return json({ task: serializeTask(existing) });
  } catch {
    return serverError();
  }
}

export async function DELETE() {
  try {
    const userId = await getTaskOwnerId();
    const removed = await db
      .delete(tasks)
      .where(and(eq(tasks.userId, userId), eq(tasks.completed, true)))
      .returning({ id: tasks.id });
    return json({ ok: true, removed: removed.length });
  } catch {
    return serverError();
  }
}
