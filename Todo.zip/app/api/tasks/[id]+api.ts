import { and, eq } from 'drizzle-orm';
import { z } from 'zod';
import { badRequest, getTaskOwnerId, json, serverError } from '@/lib/api';
import { db } from '@/lib/db';
import { tasks } from '@/lib/schema';
import { serializeTask } from '@/lib/serialize';

const updateSchema = z
  .object({
    completed: z.boolean().optional(),
    priority: z.enum(['low', 'medium', 'high']).optional(),
    title: z.string().trim().min(1).max(120).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, { message: 'Nothing to update.' });

export async function PATCH(request: Request, { id }: Record<string, string>) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return badRequest('Invalid request body.');
  }

  const parsed = updateSchema.safeParse(payload);
  if (!parsed.success) {
    return badRequest(parsed.error.issues[0]?.message ?? 'Invalid update.');
  }

  const updates: Record<string, unknown> = {};
  if (parsed.data.title !== undefined) updates.title = parsed.data.title;
  if (parsed.data.priority !== undefined) updates.priority = parsed.data.priority;
  if (parsed.data.completed !== undefined) {
    updates.completed = parsed.data.completed;
    updates.completedAt = parsed.data.completed ? new Date() : null;
  }

  try {
    const userId = await getTaskOwnerId();
    const [row] = await db
      .update(tasks)
      .set(updates)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();

    if (!row) return json({ error: 'Task not found.' }, 404);
    return json({ task: serializeTask(row) });
  } catch {
    return serverError();
  }
}

export async function DELETE(_request: Request, { id }: Record<string, string>) {
  try {
    const userId = await getTaskOwnerId();
    const [row] = await db
      .delete(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning({ id: tasks.id });

    if (!row) return json({ error: 'Task not found.' }, 404);
    return json({ ok: true });
  } catch {
    return serverError();
  }
}
