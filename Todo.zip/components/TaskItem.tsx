import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Check, Trash2 } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { colors, priorityMeta, radius, shadow } from '@/constants/theme';
import type { Task } from '@/lib/types';

type Props = {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
};

export function TaskItem({ task, onToggle, onDelete }: Props) {
  const priority = priorityMeta[task.priority];

  const handleToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    onToggle(task.id);
  };

  return (
    <View style={[styles.card, task.completed && styles.cardDone]}>
      <Pressable
        onPress={handleToggle}
        hitSlop={8}
        accessibilityRole="checkbox"
        accessibilityState={{ checked: task.completed }}
        accessibilityLabel={`${task.completed ? 'Uncomplete' : 'Complete'} ${task.title}`}
        style={[styles.checkbox, task.completed && styles.checkboxDone]}
      >
        {task.completed ? <Check size={15} color="#FFFFFF" strokeWidth={3} /> : null}
      </Pressable>

      <View style={[styles.emojiWrap, { backgroundColor: task.completed ? colors.bg : colors.accentSoft }]}>
        <Text style={styles.emoji}>{task.emoji}</Text>
      </View>

      <View style={styles.body}>
        <Text
          style={[styles.title, task.completed && styles.titleDone]}
          numberOfLines={2}
        >
          {task.title}
        </Text>
        <View style={styles.metaRow}>
          <View style={[styles.priorityDot, { backgroundColor: priority.color }]} />
          <Text style={styles.metaText}>
            {task.category} · {priority.label}
          </Text>
        </View>
      </View>

      <Pressable
        onPress={() => onDelete(task.id)}
        hitSlop={10}
        accessibilityRole="button"
        accessibilityLabel={`Delete ${task.title}`}
        style={({ pressed }) => [styles.deleteBtn, pressed && styles.deleteBtnPressed]}
      >
        <Trash2 size={16} color={colors.textMuted} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 12,
    ...shadow.card,
  },
  cardDone: {
    backgroundColor: '#140D24',
  },
  checkbox: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: '#3A2F55',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxDone: {
    backgroundColor: colors.success,
    borderColor: colors.success,
  },
  emojiWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emoji: {
    fontSize: 22,
  },
  body: {
    flex: 1,
    gap: 5,
  },
  title: {
    fontSize: 15.5,
    fontWeight: '600',
    color: colors.text,
    lineHeight: 20,
  },
  titleDone: {
    color: colors.textMuted,
    textDecorationLine: 'line-through',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  priorityDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  metaText: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '500',
  },
  deleteBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteBtnPressed: {
    backgroundColor: colors.dangerSoft,
  },
});
