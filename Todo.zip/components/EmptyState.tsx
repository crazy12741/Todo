import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, shadow } from '@/constants/theme';

type Props = {
  emoji: string;
  title: string;
  message: string;
  tone?: 'accent' | 'success';
};

export function EmptyState({ emoji, title, message, tone = 'accent' }: Props) {
  return (
    <View style={styles.wrap}>
      <View style={[styles.badge, tone === 'success' && styles.badgeSuccess]}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    paddingVertical: 56,
    gap: 10,
  },
  badge: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: colors.accentSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
    ...shadow.card,
  },
  badgeSuccess: {
    backgroundColor: colors.successSoft,
  },
  emoji: {
    fontSize: 44,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    textAlign: 'center',
  },
  message: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 21,
    maxWidth: 280,
  },
  card: {
    borderRadius: radius.lg,
  },
});
