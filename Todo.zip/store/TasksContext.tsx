import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { ApiError, createTask, fetchTasks, removeTask, updateTask } from '@/lib/tasks-api';
import {
  generateTaskId,
  loadQueue,
  loadTasks,
  saveQueue,
  saveTasks,
  type PendingOp,
} from '@/lib/local-store';
import { detectEmoji } from '@/lib/emoji';
import type { Priority, Task, TaskDraft } from '@/lib/types';

type TasksContextValue = {
  tasks: Task[];
  loading: boolean;
  offline: boolean;
  pendingCount: number;
  error: string | null;
  addTask: (draft: TaskDraft) => Promise<Task>;
  toggleTask: (id: string) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  updatePriority: (id: string, priority: Priority) => Promise<void>;
  clearCompleted: () => Promise<void>;
  reload: () => Promise<void>;
};

const TasksContext = createContext<TasksContextValue | null>(null);

function sortTasks(tasks: Task[]): Task[] {
  const order: Record<Priority, number> = { high: 0, medium: 1, low: 2 };
  return [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    if (a.completed && b.completed) return (b.completedAt ?? 0) - (a.completedAt ?? 0);
    const byPriority = order[a.priority] - order[b.priority];
    if (byPriority !== 0) return byPriority;
    return b.createdAt - a.createdAt;
  });
}

export function TasksProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [offline, setOffline] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const tasksRef = useRef<Task[]>([]);
  const queueRef = useRef<PendingOp[]>([]);
  const flushingRef = useRef(false);

  const commitTasks = useCallback((next: Task[]) => {
    const sorted = sortTasks(next);
    tasksRef.current = sorted;
    setTasks(sorted);
    void saveTasks(sorted);
  }, []);

  const commitQueue = useCallback((next: PendingOp[]) => {
    queueRef.current = next;
    setPendingCount(next.length);
    void saveQueue(next);
  }, []);

  const enqueue = useCallback(
    (op: PendingOp) => {
      commitQueue([...queueRef.current, op]);
    },
    [commitQueue]
  );

  const mergeRemote = useCallback(
    (remote: Task[]) => {
      const localIds = new Set(tasksRef.current.map((task) => task.id));
      const additions = remote.filter((task) => !localIds.has(task.id));
      if (additions.length > 0) {
        commitTasks([...additions, ...tasksRef.current]);
      }
    },
    [commitTasks]
  );

  const flush = useCallback(async () => {
    if (flushingRef.current) return;
    flushingRef.current = true;

    try {
      let queue = [...queueRef.current];

      while (queue.length > 0) {
        const op = queue[0];
        try {
          if (op.kind === 'create') {
            await createTask({
              id: op.task.id,
              title: op.task.title,
              priority: op.task.priority,
              completed: op.task.completed,
            });
          } else if (op.kind === 'update') {
            await updateTask(op.id, op.changes);
          } else {
            await removeTask(op.id);
          }
          queue = queue.slice(1);
          commitQueue(queue);
        } catch (err) {
          const status = err instanceof ApiError ? err.status : 0;
          if (status === 404 || status === 409) {
            queue = queue.slice(1);
            commitQueue(queue);
            continue;
          }
          setOffline(true);
          return;
        }
      }

      try {
        const remote = await fetchTasks();
        setOffline(false);
        mergeRemote(remote);
      } catch {
        setOffline(true);
      }
    } finally {
      flushingRef.current = false;
    }
  }, [commitQueue, mergeRemote]);

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        const [stored, queue] = await Promise.all([loadTasks(), loadQueue()]);
        if (!alive) return;
        tasksRef.current = sortTasks(stored);
        queueRef.current = queue;
        setTasks(tasksRef.current);
        setPendingCount(queue.length);
      } catch {
        if (alive) setError('Could not read tasks saved on this device.');
      } finally {
        if (alive) setLoading(false);
      }
      void flush();
    })();

    return () => {
      alive = false;
    };
  }, [flush]);

  const addTask = useCallback(
    async (draft: TaskDraft) => {
      const title = draft.title.trim();
      const { emoji, category } = detectEmoji(title);
      const task: Task = {
        id: generateTaskId(),
        title,
        emoji,
        category,
        priority: draft.priority,
        completed: false,
        createdAt: Date.now(),
      };

      commitTasks([task, ...tasksRef.current]);
      enqueue({ kind: 'create', task });
      void flush();
      return task;
    },
    [commitTasks, enqueue, flush]
  );

  const toggleTask = useCallback(
    async (id: string) => {
      const current = tasksRef.current.find((task) => task.id === id);
      if (!current) return;
      const completed = !current.completed;

      commitTasks(
        tasksRef.current.map((task) =>
          task.id === id
            ? { ...task, completed, completedAt: completed ? Date.now() : undefined }
            : task
        )
      );
      enqueue({ kind: 'update', id, changes: { completed } });
      void flush();
    },
    [commitTasks, enqueue, flush]
  );

  const deleteTask = useCallback(
    async (id: string) => {
      commitTasks(tasksRef.current.filter((task) => task.id !== id));
      enqueue({ kind: 'delete', id });
      void flush();
    },
    [commitTasks, enqueue, flush]
  );

  const updatePriority = useCallback(
    async (id: string, priority: Priority) => {
      commitTasks(tasksRef.current.map((task) => (task.id === id ? { ...task, priority } : task)));
      enqueue({ kind: 'update', id, changes: { priority } });
      void flush();
    },
    [commitTasks, enqueue, flush]
  );

  const clearCompleted = useCallback(async () => {
    const completed = tasksRef.current.filter((task) => task.completed);
    if (completed.length === 0) return;
    commitTasks(tasksRef.current.filter((task) => !task.completed));
    commitQueue([
      ...queueRef.current,
      ...completed.map<PendingOp>((task) => ({ kind: 'delete', id: task.id })),
    ]);
    void flush();
  }, [commitTasks, commitQueue, flush]);

  const value = useMemo(
    () => ({
      tasks,
      loading,
      offline,
      pendingCount,
      error,
      addTask,
      toggleTask,
      deleteTask,
      updatePriority,
      clearCompleted,
      reload: flush,
    }),
    [
      tasks,
      loading,
      offline,
      pendingCount,
      error,
      addTask,
      toggleTask,
      deleteTask,
      updatePriority,
      clearCompleted,
      flush,
    ]
  );

  return <TasksContext.Provider value={value}>{children}</TasksContext.Provider>;
}

export function useTasks() {
  const ctx = useContext(TasksContext);
  if (!ctx) throw new Error('useTasks must be used inside TasksProvider');
  return ctx;
}
